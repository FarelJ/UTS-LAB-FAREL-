var points = 0;
var clickValue = 1;
var clickMultiplier = 0;
var autoClickerCost = 10;
var autoClickerCount = 0;
var clickMultiplierCost = 50;
var clickMultiplierCount = 0;

var pointsDisplay = document.getElementById("points");
var clickValueDisplay = document.getElementById("clickValue");
var clickMultiplierDisplay = document.getElementById("clickMultiplierBought");
var autoClickerDisplay = document.getElementById("autoClickerCount");

var clickMeButton = document.getElementById("clickMe");
var buyAutoClickerButton = document.getElementById("buyAutoClicker");
var multiplyClickButton = document.getElementById("multiplyClick");

clickMultiplierDisplay.innerHTML = clickMultiplier;

clickMeButton.addEventListener("click", function() {
  points += clickValue * (clickMultiplier + 1);
  pointsDisplay.innerHTML = points;
});

buyAutoClickerButton.addEventListener("click", function() {
  if (points >= autoClickerCost) {
    points -= autoClickerCost;
    autoClickerCount++;
    pointsDisplay.innerHTML = points;
    autoClickerDisplay.innerHTML = autoClickerCount;
    setInterval(function() {
      clickMeButton.click();
    }, 1000);
  } else {
    alert("Tidak cukup uang untuk membeli auto clicker.");
  }
});

multiplyClickButton.addEventListener("click", function() {
  if (points >= clickMultiplierCost) {
    points -= clickMultiplierCost;
    clickMultiplier += 1;
    pointsDisplay.innerHTML = points;
    clickMultiplierDisplay.innerHTML = clickMultiplier;
  } else {
    alert("Tidak cukup uang untuk membeli cabang baru.");
  }
});

    


